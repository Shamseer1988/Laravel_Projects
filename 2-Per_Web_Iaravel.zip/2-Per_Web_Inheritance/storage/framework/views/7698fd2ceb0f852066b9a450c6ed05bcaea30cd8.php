
<?php $__env->startSection('title','home'); ?>

<?php $__env->startSection('content'); ?>
        <div class="mt-5">
            <div class="text-center">
                <img src="<?php echo e(asset('images/shamseer.jpg')); ?>" alt="" class="img-thumbnail" width="150px" height="auto">
            </div>
            <div class="mt-5 text-white mx=5 text-justify">
                    <h1 class="fw-bold st-font">Hello,</h1>
                    <div class="px-4" style="line-height: 2rem;">
                    <p style="text-indent:100px;"> My Name: <B class="text-warning">SHAMSEER MAKKANAMCHERY</B> from Kozhikode Kerla India .
                        I have Completed My Graduation From <i>Univercity of Calicut.</i> Currently I am Working in <B>PARIS FOOD INTERNATIONAL WLL</B>
                        Doha Qatar As a Finance Manager Since : 2009. Currently i am Learning Programming Cources From <b>IPSR Solutions Limited</b> Kochin Kerala like PHP,Phythom,Laravel,Artificial Inteligent,Android Dovelpoment etc..
                    </p>
                </div>
            </div>
            <div class="text-center">
                <a href="<?php echo e(route('contact')); ?>" class="btn btn-outline-warning mx-5 my-3">Hire Me</a>
                <a href="<?php echo e(route('contact')); ?>" class="btn btn-outline-info">Contact</a>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\LARAVEL\Per_Web_Inheritance\resources\views/home.blade.php ENDPATH**/ ?>