<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Satisfy&display=swap" rel="stylesheet">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <div class="container-fluid cus_Bground">
        <div class="row">
            <div class="col-sm-2">
                <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-sm-10">
                <?php echo $__env->yieldContent('content'); ?>
                    <!-- Footer -->
                <footer class="bg-dark text-center text-white">
                    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
                    © 2022 Copyright:
                    <a class="text-white" href="https://faizzyworld.online/">Faizzyworld.com</a>
                    </div>
                </footer>
            </div>
        </div>
    </div>


    <script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js/all.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\xampp\LARAVEL\Per_Web_Inheritance\resources\views/layouts/layouts.blade.php ENDPATH**/ ?>