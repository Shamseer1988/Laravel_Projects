<div class="border-end border-start border-white h-100">
    <div class="text-center m-2">
        <img src="<?php echo e(asset('images/shamseer.jpg')); ?>" class="img-fluid rounded-circle mt-5" alt="">
        <h3 class="text-white mt-2 st-font">Shamseer M</h3>
    </div>
<nav class="nav flex-column text-center mt-4">
    <a href="<?php echo e(Route('home')); ?>"  class="nav-link <?php echo e(Request:: routeIs('home') ? 'active' :''); ?>">Home</a>
    <a href="<?php echo e(Route('about')); ?>" class="nav-link <?php echo e(Request:: routeIs('about') ? 'active' :''); ?>">My Skill</a>
    <a href="<?php echo e(Route('services')); ?>" class="nav-link <?php echo e(Request:: routeIs('services') ? 'active' :''); ?>">Services</a>
    <a href="<?php echo e(Route('contact')); ?>" class="nav-link <?php echo e(Request:: routeIs('contact') ? 'active' :''); ?>">Contact</a>

</nav>



        <div class="text-center p-3 text-danger cus_border  position-fixed" style="background-color: hsl(45, 100%, 51%);">
                    FaizzyWorld
        </div>


</div><?php /**PATH C:\xampp\htdocs\xampp\LARAVEL\Per_Web_Inheritance\resources\views/include/sidebar.blade.php ENDPATH**/ ?>