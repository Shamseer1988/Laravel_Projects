
<?php $__env->startSection('title','Services'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
   <h1 class="text-warning mb-5 border-bottom">SERVICES</h1>

   <div class="row text-center text-white mb-5">
    <div class="col-sm-4">
     <i class="fas fa-search-dollar fa-2x mb-3 i-color"></i>
     <h3>SEO</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
    <div class="col-sm-4">
     <i class="fas fa-palette fa-2x mb-3 i-color"></i>
     <h3>Web Design</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
    <div class="col-sm-4">
     <i class="fas fa-code fa-2x mb-3 i-color"></i>
     <h3>Web Development</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
   </div>

   <div class="row text-center text-white mb-5">
    <div class="col-sm-4">
     <i class="fab fa-android fa-2x mb-3 i-color"></i>
     <h3>Android</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
    <div class="col-sm-4">
     <i class="fab fa-apple fa-2x mb-3 i-color"></i>
     <h3>iOS</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
    <div class="col-sm-4">
     <i class="fas fa-ad fa-2x mb-3 i-color"></i>
     <h3>Advertising</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
   </div>

   <div class="row text-center text-white mb-5">
    <div class="col-sm-4">
     <i class="fas fa-pencil-alt fa-2x mb-3 i-color"></i>
     <h3>Logo Design</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
    <div class="col-sm-4">
     <i class="fas fa-database fa-2x mb-3 i-color"></i>
     <h3>Hosting</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
    <div class="col-sm-4">
     <i class="fas fa-headset fa-2x mb-3 i-color"></i>
     <h3>Support</h3>
     <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, neque.</p>
    </div>
   </div>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\LARAVEL\Laravel Projects\2-Per_Web_Inheritance\resources\views/services.blade.php ENDPATH**/ ?>